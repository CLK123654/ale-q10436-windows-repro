# 课程播放器浏览器回归

app目录提供脱敏的课程视频控件。fixtures/player_cases.json保存业务场景，fixtures/caption_tracks.json保存页面和测试共用的字幕数据。请完成starter/playwright.config.ts及starter/tests/video_player_controls.spec.ts，然后在当前目录执行npm run process。

入口会分配回环端口并启动本地静态服务。测试使用Playwright1.62.x和Chromium。各场景的浏览器存储状态不能互相污染。字幕和倍速场景需要检查刷新后的页面状态；键盘场景先聚焦播放器，再发送fixtures中的按键；可访问性场景使用role、可访问名称和ARIA属性定位。

同级output目录应包含完成版配置、完成版测试以及播放器状态、快捷键、持久化、可访问性四份CSV报告。运行期间只访问入口提供的本机页面，不修改输入文件。
