import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const port=Number(process.env.PORT||0);
if(!Number.isInteger(port)||port<1)throw new Error('PORT无效');
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8'};
http.createServer(async(request,response)=>{try{const requestUrl=new URL(request.url||'/','http://127.0.0.1');const relative=decodeURIComponent(requestUrl.pathname==='/'?'/app/video.html':requestUrl.pathname).replace(/^\/+/, '');const file=path.resolve(root,relative);if(file!==root&&!file.startsWith(`${root}${path.sep}`))throw new Error('path outside root');const body=await fs.readFile(file);response.writeHead(200,{'content-type':types[path.extname(file)]||'application/octet-stream','cache-control':'no-store'});response.end(body);}catch{response.writeHead(404,{'content-type':'text/plain; charset=utf-8'});response.end('not found');}}).listen(port,'127.0.0.1',()=>console.log(`video fixture listening on ${port}`));
