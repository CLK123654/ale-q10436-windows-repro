import fs from 'node:fs/promises';
import net from 'node:net';
import path from 'node:path';
import process from 'node:process';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const inputRoot=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const packageRoot=path.dirname(inputRoot);
const outputRoot=path.join(packageRoot,'output');
const configSource=path.join(inputRoot,'starter','playwright.config.ts');
const specSource=path.join(inputRoot,'starter','tests','video_player_controls.spec.ts');
const required=['README.md','package.json','app/video.html','app/video_player.js','fixtures/caption_tracks.json','fixtures/player_cases.json','scripts/static_server.mjs','starter/playwright.config.ts','starter/tests/video_player_controls.spec.ts','tools/run-task.mjs'];
const expected=['output/playwright.config.ts','output/reports/accessibility_contract.csv','output/reports/persistence_checks.csv','output/reports/player_state_matrix.csv','output/reports/shortcut_assertions.csv','output/tests/video_player_controls.spec.ts'];
async function exists(target){try{await fs.access(target);return true;}catch{return false;}}
async function listFiles(root,current=''){const entries=await fs.readdir(path.join(root,current),{withFileTypes:true});const files=[];for(const entry of entries.sort((a,b)=>a.name.localeCompare(b.name))){const relative=path.join(current,entry.name);if(entry.isDirectory())files.push(...await listFiles(root,relative));else files.push(relative.split(path.sep).join('/'));}return files;}
async function freePort(){const server=net.createServer();await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});const address=server.address();const port=typeof address==='object'&&address?address.port:0;await new Promise(resolve=>server.close(resolve));if(!port)throw new Error('无法分配动态端口');return port;}
function playwrightCli(){return process.env.PLAYWRIGHT_CLI?path.resolve(process.env.PLAYWRIGHT_CLI):path.join(inputRoot,'node_modules','playwright','cli.js');}
async function cleanTransient(){for(const name of ['test-results','playwright-report','.playwright-artifacts'])await fs.rm(path.join(inputRoot,name),{recursive:true,force:true});}
try{
  const before=new Map();for(const relative of required){const bytes=await fs.readFile(path.join(inputRoot,...relative.split('/')));before.set(relative,bytes.toString('base64'));}
  const configText=await fs.readFile(configSource,'utf8');const specText=await fs.readFile(specSource,'utf8');
  if(/\bTODO\b/.test(configText)||/\bTODO\b/.test(specText))throw Object.assign(new Error('starter仍含TODO'),{exitCode:2});
  if(/\bSC-[A-Z0-9-]+\b/.test(specText))throw new Error('spec按scenario_id硬编码');
  for(const marker of ['browser.newContext(', 'getByRole(', 'getByTestId(', '.press(', 'localStorage.clear()', 'page.reload('])if(!specText.includes(marker))throw new Error(`spec缺少真实Playwright动作:${marker}`);
  if(!configText.includes('webServer')||!configText.includes('chromium')||!configText.includes('VIDEO_PLAYER_PORT'))throw new Error('配置缺少动态端口、本地webServer或Chromium');
  const cli=playwrightCli();if(!await exists(cli))throw Object.assign(new Error('未找到Playwright1.62.x'),{exitCode:2});
  const version=spawnSync(process.execPath,[cli,'--version'],{encoding:'utf8',windowsHide:true,timeout:10000});if(version.status!==0||!/Version 1\.62\./.test(version.stdout))throw new Error(`需要Playwright1.62.x:${version.stdout||version.stderr}`);
  await fs.rm(outputRoot,{recursive:true,force:true});await cleanTransient();await fs.mkdir(path.join(outputRoot,'tests'),{recursive:true});await fs.copyFile(configSource,path.join(outputRoot,'playwright.config.ts'));await fs.copyFile(specSource,path.join(outputRoot,'tests','video_player_controls.spec.ts'));
  const port=await freePort();const run=spawnSync(process.execPath,[cli,'test','--config',path.join(outputRoot,'playwright.config.ts')],{cwd:inputRoot,env:{...process.env,PORT:String(port),VIDEO_PLAYER_PORT:String(port),VIDEO_PLAYER_INPUT_ROOT:inputRoot,NODE_PATH:path.dirname(path.dirname(cli))},encoding:'utf8',windowsHide:true,timeout:120000});if(run.stdout)process.stdout.write(run.stdout);if(run.stderr)process.stderr.write(run.stderr);if(run.error||run.status!==0)throw new Error(`Playwright返回${run.status??'spawn_error'}`);
  await cleanTransient();const actual=(await listFiles(outputRoot)).map(name=>`output/${name}`);if(JSON.stringify(actual)!==JSON.stringify(expected))throw new Error(`交付边界错误:${actual.join('|')}`);
  for(const [relative,encoded] of before){const after=(await fs.readFile(path.join(inputRoot,...relative.split('/')))).toString('base64');if(after!==encoded)throw new Error(`输入被修改:${relative}`);}
  console.log('播放器浏览器回归完成');
}catch(error){await fs.rm(outputRoot,{recursive:true,force:true});await cleanTransient();console.error(error.message);process.exit(Number.isInteger(error?.exitCode)?error.exitCode:1);}
