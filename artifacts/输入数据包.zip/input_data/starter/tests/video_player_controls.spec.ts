import { test, expect } from 'playwright/test';
test('TODO: fixture-driven captions, rate, keyboard and accessibility',async({page})=>{await page.goto('/app/video.html');await expect(page.getByTestId('player-shell')).toBeVisible();});
