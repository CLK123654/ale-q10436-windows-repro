const tracks=await fetch('/fixtures/caption_tracks.json').then(response=>{if(!response.ok)throw new Error('caption tracks unavailable');return response.json();});
const lessons={shipping:{title:'配送承诺说明',startTime:0},returns:{title:'退货流程说明',startTime:32}};
const params=new URLSearchParams(location.search);
const lessonId=params.get('lesson')||'shipping';
const lesson=lessons[lessonId]||lessons.shipping;
let captionLang=localStorage.getItem('captionLang')||tracks[0].lang;
let playbackRate=Number(localStorage.getItem('playbackRate')||'1');
let currentTime=lesson.startTime;
let muted=false;
let playing=false;
const shell=document.querySelector('[data-testid=player-shell]');
const captionLine=document.querySelector('[data-testid=caption-line]');
const status=document.querySelector('[data-testid=player-status]');
const timecode=document.querySelector('[data-testid=timecode]');
const rateButton=document.querySelector('[data-testid=rate-button]');
const muteButton=document.querySelector('[data-testid=mute-button]');
const playButton=document.querySelector('[data-testid=play-button]');
const menu=document.querySelector('[data-testid=caption-menu]');
document.querySelector('[data-testid=lesson-title]').textContent=lesson.title;
function formatTime(value){const rounded=Math.max(0,Math.round(value));return `00:${String(rounded).padStart(2,'0')}`;}
function activeTrack(){return tracks.find(track=>track.lang===captionLang)||tracks[0];}
function render(){captionLine.textContent=activeTrack()[lessonId]||activeTrack().shipping;status.textContent=playing?'Playing':'Paused';timecode.textContent=formatTime(currentTime);rateButton.textContent=`${playbackRate.toFixed(1)}x`;muteButton.setAttribute('aria-pressed',String(muted));muteButton.textContent=muted?'Muted':'Mute';playButton.setAttribute('aria-pressed',String(playing));for(const option of menu.querySelectorAll('[role=option]'))option.setAttribute('aria-selected',String(option.dataset.lang===captionLang));}
for(const track of tracks){const option=document.createElement('button');option.type='button';option.setAttribute('role','option');option.dataset.lang=track.lang;option.textContent=track.label;option.addEventListener('click',()=>{captionLang=track.lang;localStorage.setItem('captionLang',captionLang);render();});menu.appendChild(option);}
rateButton.addEventListener('click',()=>{playbackRate=playbackRate===1?1.5:playbackRate===1.5?2:1;localStorage.setItem('playbackRate',String(playbackRate));render();});
playButton.addEventListener('click',()=>{playing=!playing;render();});
muteButton.addEventListener('click',()=>{muted=!muted;render();});
shell.addEventListener('keydown',event=>{if(event.code==='Space'){event.preventDefault();playing=!playing;}if(event.code==='ArrowRight')currentTime+=10;if(event.code==='ArrowLeft')currentTime=Math.max(0,currentTime-5);if(event.code==='KeyM')muted=!muted;if(event.code==='KeyC'){const index=tracks.findIndex(track=>track.lang===captionLang);captionLang=tracks[(index+1)%tracks.length].lang;localStorage.setItem('captionLang',captionLang);}render();});
render();
