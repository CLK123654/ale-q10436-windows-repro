import { defineConfig, devices } from 'playwright/test';
import path from 'node:path';
import process from 'node:process';
const inputRoot=path.resolve(process.env.VIDEO_PLAYER_INPUT_ROOT||process.cwd());
const port=Number(process.env.VIDEO_PLAYER_PORT);
if(!Number.isInteger(port)||port<1)throw new Error('VIDEO_PLAYER_PORT无效');
export default defineConfig({
  testDir:path.join(inputRoot,'..','output','tests'),
  workers:1,
  retries:0,
  timeout:30000,
  reporter:'line',
  outputDir:path.join(inputRoot,'test-results'),
  use:{...devices['Desktop Chrome'],baseURL:`http://127.0.0.1:${port}`,trace:'off',screenshot:'off',video:'off'},
  projects:[{name:'chromium',use:{browserName:'chromium'}}],
  webServer:{command:`"${process.execPath}" "${path.join(inputRoot,'scripts','static_server.mjs')}"`,url:`http://127.0.0.1:${port}/app/video.html`,reuseExistingServer:false,timeout:15000,env:{PORT:String(port)}}
});
